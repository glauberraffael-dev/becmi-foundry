/**
 * Foundry-independent smoke test for sheet drop handling.
 *
 * Usage: node tools/test-sheets.mjs
 */
import { readFile } from "node:fs/promises";

class FakeActorSheet {
  static DEFAULT_OPTIONS = { actions: { editImage: () => "edited" } };

  constructor() {
    this.superDrops = [];
    this.superItems = [];
    this.editable = true;
    this.actor = { id: "actor" };
  }

  get isEditable() { return this.editable; }

  async _onDrop(event) {
    this.superDrops.push(event);
    return "super-drop";
  }

  async _onDropItem(event, item) {
    this.superItems.push(item);
    return item;
  }

  async render() {}
}

let dragPayload = {};
globalThis.foundry = {
  applications: {
    api: { HandlebarsApplicationMixin: (Base) => Base },
    sheets: { ActorSheetV2: FakeActorSheet, ItemSheetV2: class {} },
    ux: { TextEditor: { implementation: { getDragEventData: () => dragPayload } } }
  },
  utils: {
    mergeObject: (base, extra) => ({
      ...base,
      ...extra,
      actions: { ...(base.actions ?? {}), ...(extra.actions ?? {}) }
    }),
    deepClone: (value) => structuredClone(value),
    getProperty: (object, path) => path.split(".").reduce((value, part) => value?.[part], object),
    setProperty: (object, path, value) => {
      const parts = path.split(".");
      const last = parts.pop();
      const target = parts.reduce((node, part) => (node[part] ??= {}), object);
      target[last] = value;
    },
    deleteProperty: (object, path) => {
      const parts = path.split(".");
      const last = parts.pop();
      const target = parts.reduce((node, part) => node?.[part], object);
      if (target) delete target[last];
    }
  }
};
globalThis.game = { i18n: { localize: (key) => key, format: (key) => key }, userId: "gm" };
globalThis.ui = { notifications: { warn() {}, info() {} } };

const { BECMIActorSheet } = await import("../scripts/sheets/actor-sheet.mjs");
if (typeof BECMIActorSheet.DEFAULT_OPTIONS.actions.editImage !== "function") {
  throw new Error("the inherited editImage action was dropped from actor sheet options");
}
const sheet = new BECMIActorSheet({});
sheet.editMode = true; // drops are edit actions; use mode is tested below
const event = {};
const classItem = { documentName: "Item", type: "class", name: "Magic-User" };

// Non-spell items must reach the standard ActorSheetV2 creation path.
const classResult = await sheet._onDropItem(event, classItem);
if (classResult !== classItem || sheet.superItems[0] !== classItem) {
  throw new Error("class items are no longer delegated to ActorSheetV2");
}

// Owned items are reordering and must also use the standard handler.
const owned = { documentName: "Item", type: "weapon", parent: sheet.actor };
await sheet._onDropItem(event, owned);
if (sheet.superItems[1] !== owned) throw new Error("owned items are not delegated");

// Payloads without a document must not raise an unhandled fromDropData error.
dragPayload = {};
if (await sheet._onDrop(event) !== null || sheet.superDrops.length !== 0) {
  throw new Error("undocumented drag payload was forwarded to ActorSheetV2");
}

// Valid document payloads still use the inherited handler.
dragPayload = { uuid: "Compendium.becmi.classes.Item.magicuser", type: "Item" };
if (await sheet._onDrop(event) !== "super-drop" || sheet.superDrops.length !== 1) {
  throw new Error("document drag payload was not forwarded to ActorSheetV2");
}

// Use mode must not submit actor changes through edit actions.
const actions = BECMIActorSheet.DEFAULT_OPTIONS.actions;
sheet.editMode = false;
sheet.actor = {
  async update() { throw new Error("read-only sheet tried to update the actor"); }
};
if (sheet.editMode) throw new Error("sheets must open in use mode");
await actions.levelUp.call(sheet);
await actions.memorizeSpell.call(sheet, {}, { dataset: { itemId: "spell" } });
await actions.setClass.call(sheet, {}, { dataset: { classKey: "fighter" } });
await actions.toggleEditMode.call(sheet);
if (!sheet.editMode) throw new Error("edit mode toggle did not enable editing");
await actions.toggleEditMode.call(sheet);
if (sheet.editMode) throw new Error("edit mode toggle did not return to use mode");

// Use mode still accepts the live HP tracker, but no other actor edit.
const updates = [];
sheet.editable = true;
sheet.actor = {
  async update(changes) { updates.push(changes); }
};
const submit = BECMIActorSheet.DEFAULT_OPTIONS.form.handler;
await submit.call(sheet, {}, {}, {
  object: {
    "system.attributes.hp.value": "7",
    "system.attributes.hp.max": "12",
    "system.attributes.xp": "5000",
    "system.attributes.xpNext": "9999"
  }
});
if (updates.length !== 1 || Object.keys(updates[0]).join() !== "system.attributes.hp.value"
  || updates[0]["system.attributes.hp.value"] !== 7) {
  throw new Error(`use mode must only track current HP, got ${JSON.stringify(updates)}`);
}

// Switching class stores the RC snapshot, never a writable xpNext threshold.
updates.length = 0;
sheet.editMode = true;
await actions.setClass.call(sheet, {}, { dataset: { classKey: "fighter" } });
const classUpdate = updates[0] ?? {};
if ("system.attributes.xpNext" in classUpdate) {
  throw new Error("class selection wrote the derived xpNext field");
}
if (classUpdate["flags.becmi.classInfo"]?.key !== "fighter") {
  throw new Error("class selection did not store the RC class snapshot");
}

// The selector is a real form field, so submitting it must expand the snapshot.
updates.length = 0;
sheet.editMode = true;
sheet.actor = {
  system: { attributes: { level: 1 } },
  async update(changes) { updates.push(changes); }
};
await submit.call(sheet, {}, {}, {
  object: {
    "system.attributes.classKey": "magic-user",
    "system.attributes.xpNext": "9999"
  }
});
const formClassUpdate = updates[0] ?? {};
if (formClassUpdate["system.attributes.classKey"] !== "magic-user"
  || formClassUpdate["system.attributes.class"] !== "Magic-User"
  || formClassUpdate["flags.becmi.classInfo"]?.key !== "magic-user"
  || "system.attributes.xpNext" in formClassUpdate) {
  throw new Error(`class field submit did not apply the RC snapshot: ${JSON.stringify(updates)}`);
}

// A manual level edit rolls HP once, then ignores the stale HP fields that the
// form still carries; otherwise the rolled maximum is immediately overwritten.
const { classInfoFromRC } = await import("../scripts/integrations.mjs");
updates.length = 0;
sheet.editMode = true;
sheet.actor = {
  system: {
    attributes: { level: 1, hp: { value: 4, max: 4 } },
    abilities: { con: { value: 10 } }
  },
  flags: { becmi: { classInfo: classInfoFromRC("Fighter") } },
  async update(changes) { updates.push(changes); }
};
await submit.call(sheet, {}, {}, {
  object: {
    "system.attributes.level": "2",
    "system.attributes.hp.value": "4",
    "system.attributes.hp.max": "4",
    "system.attributes.xp": "2000"
  }
});
if (updates.length !== 2) {
  throw new Error(`manual level edit produced ${updates.length} updates: ${JSON.stringify(updates)}`);
}
const [levelUpdate, otherUpdate] = updates;
if (levelUpdate["system.attributes.level"] !== 2
  || !(levelUpdate["system.attributes.hp"]?.max > 4)
  || Number(otherUpdate["system.attributes.xp"]) !== 2000
  || "system.attributes.hp.value" in otherUpdate
  || "system.attributes.hp.max" in otherUpdate) {
  throw new Error(`manual level edit did not roll HP canonically: ${JSON.stringify(updates)}`);
}

// Monster sheets expose one button per save and a named pair per attack row.
const body = await readFile(new URL("../templates/actor/body.hbs", import.meta.url), "utf8");
if (!body.includes('data-action="rollSave" data-save="{{save.key}}"')
  || !body.includes('data-action="monsterAttack" data-attack-index="{{attack.index}}"')
  || !body.includes('data-action="monsterDamage" data-attack-index="{{attack.index}}"')
  || !body.includes('data-action="rollInitiative"')
  || !body.includes('data-action="rollMonsterHp"')
  || !body.includes("{{#if monsterSpellcaster}}")
  || !body.includes('name="system.spellcasting"')
  || !body.includes('data-tab="equipment"')) {
  throw new Error("monster save, HP, initiative, weapon or spell buttons are missing from the sheet template");
}
const equipmentPartial = await readFile(new URL("../templates/actor/parts/equipment.hbs", import.meta.url), "utf8");
if (!equipmentPartial.includes('data-action="itemAttack"')
  || !equipmentPartial.includes('data-action="itemDamage"')) {
  throw new Error("equipment partial must expose weapon attack and damage buttons");
}
const rolled = [];
sheet.actor = {
  async rollSave(key) { rolled.push(["save", key]); },
  async rollInitiative() { rolled.push(["initiative"]); },
  async rollMonsterHitPoints() { rolled.push(["monsterHp"]); },
  async rollMonsterAttack(index, options) {
    rolled.push(["attack", index, options?.targetAC, options?.mode]);
  },
  async rollMonsterDamage(index) { rolled.push(["damage", index]); }
};
await actions.rollSave.call(sheet, {}, { dataset: { save: "breath" } });
await actions.rollInitiative.call(sheet);
sheet.editMode = false; // rolling HP is an action, available in use mode
await actions.rollMonsterHp.call(sheet);
await actions.monsterAttack.call(sheet, {}, { dataset: { attackIndex: "2" } });
await actions.monsterDamage.call(sheet, {}, { dataset: { attackIndex: "2" } });
if (JSON.stringify(rolled) !== JSON.stringify([
  ["save", "breath"], ["initiative"], ["monsterHp"], ["attack", 2, 9, "attack"], ["damage", 2]
])) {
  throw new Error(`monster roll actions did not reach the actor: ${JSON.stringify(rolled)}`);
}

// Name-level controls stay in the template and their actions reach the actor
// even in use mode (they are rolls, not edits).
if (!body.includes('name="system.nameLevel.path"')
  || !body.includes("../nameLevelStored.path")
  || !body.includes("../nameLevelStored.specialization")
  || !body.includes("../nameLevelStored.holdingStyle")
  || !body.includes('{{#if (eq nameLevel.requested "avenger")}}')
  || !body.includes('data-action="detectEvil"')
  || !body.includes("{{#each nameLevel.pros as |line|}}")
  || !body.includes("{{#each nameLevel.cons as |line|}}")) {
  throw new Error("name-level persisted selectors, Detect Evil button or pros/cons panel are missing");
}
const nameRolls = [];
sheet.editMode = false;
sheet.turnUndeadLevel = 3;
sheet.nameLevel = { canDetectEvil: true, isAvenger: true };
sheet.actor = {
  async rollTurnUndead(type, options) { nameRolls.push(["undead", type, options?.level, options?.control]); },
  async rollDetectEvil() { nameRolls.push(["detectEvil"]); }
};
await actions.rollTurnUndead.call(sheet, {}, { dataset: { undead: "Skeleton" } });
await actions.detectEvil.call(sheet);
if (JSON.stringify(nameRolls) !== JSON.stringify([
  ["undead", "Skeleton", 3, true], ["detectEvil"]
])) {
  throw new Error(`name-level roll actions did not reach the actor: ${JSON.stringify(nameRolls)}`);
}

// Optional weapon mastery: an always-visible toggle and a usable grade dropdown.
if (!body.includes('data-action="toggleMastery"')
  || !body.includes('name="system.mastery.enabled"')
  || !body.includes("{{grade.name}}")) {
  throw new Error("the optional weapon-mastery toggle or grade dropdown is missing from the sheet");
}
let masteryUpdate = null;
sheet.editable = true;
sheet.editMode = true;
sheet.actor = {
  system: { mastery: { enabled: false } },
  async update(data) { masteryUpdate = data; }
};
await actions.toggleMastery.call(sheet, {}, {});
if (masteryUpdate?.["system.mastery.enabled"] !== true) {
  throw new Error("the mastery toggle did not opt the character in");
}

console.log("Sheet handling OK (drops, invalid payloads, edit/use mode, HP tracking, class field, derived XP, monster rolls, name level and optional mastery).");
